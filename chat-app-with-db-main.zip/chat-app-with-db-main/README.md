## A chat application with database, developed in C# (WinForms & ADO.NET).

Developed as a final project in SQL Databases - as part of the .NET web development course in John Bryce college.

**Project focused on:**
- SQL Server
- Data Access Layer
- ADO.NET

_**Project is the same as [the previous chat-app](https://github.com/ohad-shai/chat-app), but now has a SQL database attached to it, with user registration and login.**_
